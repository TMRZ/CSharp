﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string path;
        string[] paths;
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            path = textBox1.Text;
            paths = path.Split(';');
            try
            {
                for (int pathIndex = 0; pathIndex < paths.Length; pathIndex++)
                {
                    string[] sonPath = Directory.GetDirectories(paths[pathIndex]);
                    string[] sonFile = Directory.GetFiles(paths[pathIndex]);
                    if (sonPath.Length != 0)
                    {
                        for (int i = 0; i < sonPath.Length; i++)
                        {
                            if (sonPath[i].Contains("副本"))
                            {
                                Directory.Delete(sonPath[i], true);
                                textBox2.AppendText(sonPath[i] + "\n---已删除\n");
                            }
                            else if (sonPath[i].Contains("快捷方式"))
                            {
                                Directory.Delete(sonPath[i], true);
                                textBox2.AppendText(sonPath[i] + "\n---已删除\n");
                            }
                        }                 
                    }
                   
                    if (sonFile.Length != 0)
                    {
                        for (int i = 0; i < sonFile.Length; i++)
                        {
                            if (sonFile[i].Contains("副本"))
                            {
                                File.Delete(sonFile[i]);
                                textBox2.AppendText(sonFile[i] + "\n---已删除\n");
                            }
                            else if (sonFile[i].Contains("快捷方式"))
                            {
                                File.Delete(sonFile[i]);
                                textBox2.AppendText(sonFile[i] + "\n---已删除\n");
                            }
                        }
                    }                                                       
                }
                MessageBox.Show("---处理完成---");
                
            }
            catch (Exception)
            {
               MessageBox.Show("程序异常！请核实输入的路径！");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
